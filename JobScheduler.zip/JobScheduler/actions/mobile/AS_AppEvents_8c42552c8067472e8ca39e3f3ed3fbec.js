function AS_AppEvents_8c42552c8067472e8ca39e3f3ed3fbec(eventobject) {
    setGestureRecogniserTofrmScheduler();
    setDeleteButtonCallBack();
}