function AS_Button_4c055e96468a44b6a31f9bc5fb12c7ea(eventobject) {
    frmScheduler.show();
}