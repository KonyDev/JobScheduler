function AS_FlexContainer_e7e934ce4085427f8e0b388b9e964d8f(eventobject, x, y) {
    if (frmLogIn.imgSwitch.src === "switch_on") frmLogIn.imgSwitch.src = "switch_off.png";
    else frmLogIn.imgSwitch.src = "switch_on.png";
}