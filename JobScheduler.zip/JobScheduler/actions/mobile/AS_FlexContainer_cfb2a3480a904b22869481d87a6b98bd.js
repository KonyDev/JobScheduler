function AS_FlexContainer_cfb2a3480a904b22869481d87a6b98bd(eventobject, context) {
    return cancelJob.call(this);
}