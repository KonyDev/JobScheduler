function AS_Button_c0338a66005b46b69513e7b13b09dc02(eventobject) {
    return scheduleJob.call(this);
}