function AS_Image_7bc501af9b794b28a59abcd3e93cb9a7(eventobject, x, y) {
    if (frmLogIn.imgSwitch.src === "switch_on.png") frmLogIn.imgSwitch.src = "switch_off.png";
    else frmLogIn.imgSwitch.src = "switch_on.png";
}